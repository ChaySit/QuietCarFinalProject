insert into utilisateur (login,password) values ('me','azerty1') ;
insert into utilisateur (login,password) values ('anotherMe','azerty2') ;
insert into utilisateur (login,password) values ('chaymaa','chay.sita@gmail.com', 'Sii', 'azerty3', 'Chay', 'Femme', '06 68 25 20 09') ; 

insert into Offre values (1,'Toulouse', '12/20/2017', 'Bourges', '21h05', 'Je fais souvent ce trajet', '1', 'SUV', 'me');
insert into Offre values (2,'Toulouse', '12/20/2017', 'Bourges', '10h30', 'J ai pas envie de laisser un message', '2', 'Clio', 'anotherMe');
insert into Offre values (3,'Toulouse', '12/20/2017', 'Bourges', '06h05', 'J aime vraiment pas le blabla', '3', 'Autre', 'chaymaa');

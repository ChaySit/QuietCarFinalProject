package entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import sun.util.calendar.BaseCalendar.Date;

@Entity
public class Offre {
	
	@Id
	private String ref;
	@ManyToOne
	private Utilisateur conducteur;
	private String depart; 
	private String arrivee;
	private String date; 
	private String heure; 
	//private List<String> villesdesservis = new ArrayList<String>(); 
	private String vehicule;
	private String nombrePlace;
	private String message;
	
	
	
	public Offre() {
		
	}
	public Offre(String ref, Utilisateur conducteur, String depart, String arrivee ,String date, String heure, String vehicule, String nombrePlace, String message) {
		this.ref = ref ; 
		this.conducteur = conducteur;
		this.depart = depart;
		this.arrivee = arrivee;
		this.date = date;
		this.heure = heure;
		this.vehicule = vehicule;
		this.nombrePlace = nombrePlace;
		this.message = message;
	}
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public Utilisateur getConducteur() {
		return conducteur;
	}
	public void setConducteur(Utilisateur conducteur) {
		this.conducteur = conducteur;
	}
	public String getDepart() {
		return depart;
	}
	public void setDepart(String depart) {
		this.depart = depart;
	}
	public String getArrivee() {
		return arrivee;
	}
	public void setArrivee(String arrivee) {
		this.arrivee = arrivee;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getVehicule() {
		return vehicule;
	}
	public void setVehicule(String vehicule) {
		this.vehicule = vehicule;
	}
	public String getNombrePlace() {
		return nombrePlace;
	}
	public void setNombrePlace(String nombrePlace) {
		this.nombrePlace = nombrePlace;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getHeure() {
		return heure;
	}
	public void setHeure(String heure) {
		this.heure = heure;
	}
	
}

package entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Reservation {
	
	@Id
	private int id;
	@ManyToOne
	private Utilisateur client;
	@OneToOne
	private Offre offreChoisie ;
	
	private int nbrDePlaceReservees;
	private String statut;
	
	
	public Reservation() {
		
	}
	
	
	public Reservation(int id, Utilisateur client, Offre offreChoisie, int nbrDePlaceReservees) {
		this.id = id;
		this.client = client;
		this.offreChoisie = offreChoisie;
		this.nbrDePlaceReservees = nbrDePlaceReservees;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Utilisateur getClient() {
		return client;
	}
	public void setClient(Utilisateur client) {
		this.client = client;
	}
	public int getNbrDePlaceReservees() {
		return nbrDePlaceReservees;
	}
	public void setNbrDePlaceReservees(int nbrDePlaceReservees) {
		this.nbrDePlaceReservees = nbrDePlaceReservees;
	}
	public Offre getOffreChoisie() {
		return offreChoisie;
	}
	public void setOffreChoisie(Offre offreChoisie) {
		this.offreChoisie = offreChoisie;
	}


	public String getStatut() {
		return statut;
	}


	public void setStatut(String statut) {
		this.statut = statut;
	}
	
	
	
	
	
	
	
	

}

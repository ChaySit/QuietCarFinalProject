package ejbs;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import entities.Offre;
import entities.Utilisateur;

/**
 * Session Bean implementation class Facade
 */
@Stateless
@LocalBean
public class Facade {
	
	    //ligne qui me permet d'acceder à la bdd (entity manager)
		@PersistenceContext(unitName="monUnite")
		EntityManager em;
		
		/*
		 * Pour retrouver un utilisateur � partir de son id
		 */
		public Utilisateur findUtilisateur(String login) {
			return em.find(Utilisateur.class,login);
		}
		
		/*
		 * Pour v�rifier le login et le mot de passe d'un utilisateur avant connexion
		 */
		public boolean utilisateurValide(String login, String password) {
			Utilisateur u = em.find(Utilisateur.class, login);
			if(u==null) {
				return false;
			}else {
				if (u.getPassword().equals(password)) {
					return true;
				}else {
					return false;
				}
			}
		}
		
		/*
		 * Fonction pour ajouter un utilisateur dans la base de donn�es 
		 */
		public void ajouterUtilisateur(String login, String nom, String prenom, String password, String mail, String telephone,
				String sexe) {
			Utilisateur u = new Utilisateur(login, nom, prenom, password, mail, telephone, sexe);
			em.persist(u);
		}
		
		
		/*
		 * Fonction pour rechercher un trajet dans la base des offres 
		 */
		public List<Offre> rechercherTrajet(String villeDeDepart, String villeArrivee, String date, String nbrePlaces){
			//List<Offre> listeDesOffres = new ArrayList<Offre>();
			Query q = em.createQuery("Select off From Offre off where (off.depart=? and off.arrivee=? and off.date=? and off.nombrePlace>=?)");
			q.setParameter(1, villeDeDepart);
			q.setParameter(2, villeArrivee);
			q.setParameter(3, date);
			q.setParameter(4, nbrePlaces);
			return q.getResultList();
		}
		
}

package ejbs;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entities.Offre;
import entities.Utilisateur;

@Stateless
@LocalBean
public class TReservationEJB {
	
	@PersistenceContext(unitName="monUnite")
	EntityManager em;
	
	/*public void afficherReservation(String login){
		Utilisateur user = em.find(Utilisateur.class, login);
		
		
	}*/
	
	public void reserver(Offre offre, String login) {
		//gestion nombre de places 
		
		//
		
	}
	
	


}

package ejbs;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import entities.Offre;
import entities.Utilisateur;

@Stateless
@LocalBean
public class TPropositionEJB {
	
	@PersistenceContext(unitName="monUnite")
	EntityManager em;

	public void ajouterPropositionTrajet(String ref , Utilisateur cond, String depart, String arrivee , String date, String heure, String vehicule, String nbrPlace, String message) {
		Offre off = new Offre(ref,cond,depart, arrivee ,date, heure, vehicule,nbrPlace, message);
		em.persist(off);
	}
	
	public Utilisateur recupererUtilisateur(String login) {
		Utilisateur user = em.find(Utilisateur.class, login);
		return user;
		
	}
	
	public List<Offre> rechercherOffresProposees(String login){
		Utilisateur user = em.find(Utilisateur.class, login);		
		Query q = em.createQuery("Select off From Offre off where (off.conducteur=?)");
		q.setParameter(1, user);
		return q.getResultList();
	}
}
